var searchData=
[
  ['texture_5fcoordinate',['texture_coordinate',['../classsfg_1_1PrimitiveVertex.html#a02d2222e1f53bb0ee21fe520e4591581',1,'sfg::PrimitiveVertex']]]
];
