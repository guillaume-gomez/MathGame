var searchData=
[
  ['matches',['Matches',['../classsfg_1_1Selector.html#a677ed0c79f13074c0bc898ed2d17ad9d',1,'sfg::Selector']]],
  ['move',['Move',['../classsfg_1_1Fixed.html#a58b584a7756a79aa98bcb53900cf4246',1,'sfg::Fixed']]]
];
