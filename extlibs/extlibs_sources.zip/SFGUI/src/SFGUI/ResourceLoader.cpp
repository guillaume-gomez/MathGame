#include <SFGUI/ResourceLoader.hpp>

namespace sfg {

}
