#pragma once

// This header CAN be used for convenience to include
// all renderers SFGUI provides.

#include <SFGUI/Renderers/NonLegacyRenderer.hpp>
#include <SFGUI/Renderers/VertexBufferRenderer.hpp>
#include <SFGUI/Renderers/VertexArrayRenderer.hpp>
