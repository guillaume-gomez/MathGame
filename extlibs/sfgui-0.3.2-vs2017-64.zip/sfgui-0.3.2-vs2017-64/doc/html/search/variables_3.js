var searchData=
[
  ['m_5fdefault_5fviewport',['m_default_viewport',['../classsfg_1_1Renderer.html#a9e403ffaf49c1d7a3b6ae1c7e4b510f3',1,'sfg::Renderer']]],
  ['m_5fforce_5fredraw',['m_force_redraw',['../classsfg_1_1Renderer.html#a3c9fab3eadb2e300178d644509775c26',1,'sfg::Renderer']]],
  ['m_5findex_5fcount',['m_index_count',['../classsfg_1_1Renderer.html#ac8acb95da74eb12ae55322b2ca2878ce',1,'sfg::Renderer']]],
  ['m_5flast_5fwindow_5fsize',['m_last_window_size',['../classsfg_1_1Renderer.html#afff246063aade45353ec57fc8f3f6f56',1,'sfg::Renderer']]],
  ['m_5fprimitives',['m_primitives',['../classsfg_1_1Renderer.html#a8416ca1ac576e624ddcd574e72fada35',1,'sfg::Renderer']]],
  ['m_5ftexture_5fatlas',['m_texture_atlas',['../classsfg_1_1Renderer.html#a5eb5b7fd0d6efc0860bed9c6ff7d1f2e',1,'sfg::Renderer']]],
  ['m_5fvertex_5fcount',['m_vertex_count',['../classsfg_1_1Renderer.html#a38fb2d23bc9ab38c3e15d0f850f0e7c2',1,'sfg::Renderer']]],
  ['m_5fwindow_5fsize',['m_window_size',['../classsfg_1_1Renderer.html#ae6f4138093aaab1747575aee2b0a3e43',1,'sfg::Renderer']]]
];
