var searchData=
[
  ['widgetslist',['WidgetsList',['../classsfg_1_1Container.html#a6820bce566f25ba94ea0af782dca6591',1,'sfg::Container::WidgetsList()'],['../classsfg_1_1Widget.html#af4f18f6ae624e47847272d82253b3bee',1,'sfg::Widget::WidgetsList()']]]
];
