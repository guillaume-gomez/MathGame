var searchData=
[
  ['size',['size',['../classsfg_1_1PrimitiveTexture.html#a5ae9d53ca65ee264c8db920af15f33c8',1,'sfg::PrimitiveTexture::size()'],['../structsfg_1_1priv_1_1RendererTextureNode.html#a75d4ef2368b7f59c6ffaa78b111b2645',1,'sfg::priv::RendererTextureNode::size()']]],
  ['spacing',['spacing',['../classsfg_1_1priv_1_1TableOptions.html#acfc5a2a32d2d9e4e5567d2755570fb32',1,'sfg::priv::TableOptions']]]
];
